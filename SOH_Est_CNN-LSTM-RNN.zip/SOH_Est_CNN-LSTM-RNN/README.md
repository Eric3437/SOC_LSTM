# SOH_Est_CNN-LSTM
2022-2 Capstone design, SOH Estimation Using Combined CNN-LSTM Model

If .fit method does not work, try following:
1. Removed the library path under Environment variables
2. copied zlibwapi.dll to C:\Windows\System32 and C:\Windows\SysWOW64
3. Either delete/keep zlib123dllx64 file, I choose to delete as it does not need the location to library path
Solution from: https://stackoverflow.com/questions/72356588/could-not-locate-zlibwapi-dll-please-make-sure-it-is-in-your-library-path